package com.elm.constant;

/**
 * 信息提示常量类
 */
public class MessageConstant {

    public static final String ACCOUNT_EXIST = "账号已存在";
    public static final String PASSWORD_ERROR = "密码错误";
    public static final String ACCOUNT_NOT_FOUND = "账号不存在";
    public static final String ACCOUNT_LOCKED = "账号被锁定";
    public static final String EMAIL_REPEAT = "邮箱已注册";
    public static final String QQ_REPEAT = "QQ已注册";
    public static final String WECHAT_REPEAT = "微信已注册";
    public static final String FILE_NOT_FOUND = "文件未找到";
    public static final String PERMISSION_DENIED = "权限不足";
    public static final String FILE_MESSAGE_WRONG = "文件信息错误";
    public static final String FILE_READ_ERROR = "文件读入错误";
    public static final String ILLEGAL_FILE_NAME = "非法文件名";
    public static final String FAILED_CREATE_DIRECTORY = "未能成功创建文件及";
    public static final String UNKNOWN_ERROR = "未知错误";
    public static final String USER_NOT_LOGIN = "用户未登录";
    public static final String CATEGORY_BE_RELATED_BY_SETMEAL = "当前分类关联了套餐,不能删除";
    public static final String CATEGORY_BE_RELATED_BY_DISH = "当前分类关联了菜品,不能删除";
    public static final String SHOPPING_CART_IS_NULL = "购物车数据为空，不能下单";
    public static final String ADDRESS_BOOK_IS_NULL = "用户地址为空，不能下单";
    public static final String LOGIN_FAILED = "登录失败";
    public static final String UPLOAD_FAILED = "文件上传失败";
    public static final String SETMEAL_ENABLE_FAILED = "套餐内包含未启售菜品，无法启售";
    public static final String PASSWORD_EDIT_FAILED = "密码修改失败";
    public static final String DISH_ON_SALE = "起售中的菜品不能删除";
    public static final String SETMEAL_ON_SALE = "起售中的套餐不能删除";
    public static final String DISH_BE_RELATED_BY_SETMEAL = "当前菜品关联了套餐,不能删除";
    public static final String ORDER_STATUS_ERROR = "订单状态错误";
    public static final String ORDER_NOT_FOUND = "订单不存在";
    public static final String COMMENT_CREATION_FAILED = "Failed to create comment."; // 添加此行
    public static final String COMMENT_UPDATE_FAILED = "Failed to update comment."; // 添加此行
}
