package com.elm.exception;

public class FileUploadException extends BaseException {
    private static final long serialVersionUID = 1L;
    public FileUploadException() {

    }
    public FileUploadException(String message) {
        super(message);
    }
}
