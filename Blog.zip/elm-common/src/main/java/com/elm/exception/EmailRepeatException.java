package com.elm.exception;

public class EmailRepeatException extends BaseException {
    public EmailRepeatException(String msg) {super(msg);}
    public EmailRepeatException(){}
}
